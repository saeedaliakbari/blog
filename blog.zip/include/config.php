<?php

//define const 
define("DNS", "mysql:host=localhost;dbname=bashgaha_blog;charset=utf8");
define("DB_USER", "bashgaha_blog");
define("DB_PASS", "%voxYq{YRl@8");

?>