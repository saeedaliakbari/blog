<?php


$db=new PDO(DNS,DB_USER,DB_PASS);

?>